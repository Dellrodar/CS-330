﻿///////////////////////////////////////////////////////////////////////////////
// shadermanager.cpp
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager *pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	// free up the allocated memory
	m_pShaderManager = NULL;
	if (NULL != m_basicMeshes)
	{
		delete m_basicMeshes;
		m_basicMeshes = NULL;
	}
	// clear the collection of defined materials
	m_objectMaterials.clear();
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glGenTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.ambientColor = m_objectMaterials[index].ambientColor;
			material.ambientStrength = m_objectMaterials[index].ambientStrength;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationX * rotationY * rotationZ * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
			m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/

 /***********************************************************
  *  LoadSceneTextures()
  *
  *  This method is used for preparing the 3D scene by loading
  *  the shapes, textures in memory to support the 3D scene
  *  rendering
  ***********************************************************/
void SceneManager::LoadSceneTextures()
{
	/*** STUDENTS - add the code BELOW for loading the textures that ***/
	/*** will be used for mapping to objects in the 3D scene. Up to  ***/
	/*** 16 textures can be loaded per scene. Refer to the code in   ***/
	/*** the OpenGL Sample for help.                                 ***/
	m_loadedTextures = 0;

	bool bReturn = false;

	// Load textures from Utils
	bReturn = CreateGLTexture("./Utilities/textures/fine-light-wood.jpg", "floor");
	bReturn = CreateGLTexture("./Utilities/textures/Koto-light-wood.jpg", "main-body");
	bReturn = CreateGLTexture("./Utilities/textures/red-wood-mid.jpg", "legs");
	bReturn = CreateGLTexture("./Utilities/textures/white-tile.jpg", "drawer");
	bReturn = CreateGLTexture("./Utilities/textures/Glass.jpg", "glass");
	bReturn = CreateGLTexture("./Utilities/textures/blue_book_cover.jpg", "blue_book");
	bReturn = CreateGLTexture("./Utilities/textures/paper.jpg", "paper");
	bReturn = CreateGLTexture("./Utilities/textures/red_book_cover.jpg", "red_book");
	// after the texture image data is loaded into memory, the
	// loaded textures need to be bound to texture slots - there
	// are a total of 16 available slots for scene textures
	BindGLTextures();
}

/***********************************************************
* DefineObjectMaterials()
 *
* This method is used for configuring the various material
* se�ngs for all of the objects in the 3D scene.
***********************************************************/
void SceneManager::DefineObjectMaterials()
{
	// -- - Matte floor(very low reflectance) -- -
	OBJECT_MATERIAL matteFloor;
	matteFloor.ambientColor = glm::vec3(0.15f, 0.15f, 0.15f);
	matteFloor.ambientStrength = 0.02f;
	matteFloor.diffuseColor = glm::vec3(0.35f, 0.35f, 0.35f); // light gray but not pure white
	matteFloor.specularColor = glm::vec3(0.0f);
	matteFloor.shininess = 2.0f;
	matteFloor.tag = "matteFloor";
	m_objectMaterials.push_back(matteFloor);

	// light wood (matte)
	OBJECT_MATERIAL lightWoodMaterial;
	lightWoodMaterial.ambientColor = glm::vec3(0.15f, 0.15f, 0.15f);
	lightWoodMaterial.ambientStrength = 0.03f;
	lightWoodMaterial.diffuseColor = glm::vec3(0.6f, 0.6f, 0.6f); // More neutral
	lightWoodMaterial.specularColor = glm::vec3(0.02f, 0.02f, 0.02f);
	lightWoodMaterial.shininess = 4.0f;
	lightWoodMaterial.tag = "light wood";
	m_objectMaterials.push_back(lightWoodMaterial);

	// wood (subtle specular)
	OBJECT_MATERIAL woodMaterial;
	woodMaterial.ambientColor = glm::vec3(0.26f, 0.19f, 0.09f);
	woodMaterial.ambientStrength = 0.09f;                          
	woodMaterial.diffuseColor = glm::vec3(0.48f, 0.34f, 0.22f);
	woodMaterial.specularColor = glm::vec3(0.015f, 0.015f, 0.015f);
	woodMaterial.shininess = 4.0f;                                 
	woodMaterial.tag = "wood";
	m_objectMaterials.push_back(woodMaterial);

	// pure white material for lampshade
	OBJECT_MATERIAL whiteMaterial;
	whiteMaterial.ambientColor = glm::vec3(0.1f, 0.1f, 0.1f);
	whiteMaterial.ambientStrength = 0.02f;
	whiteMaterial.diffuseColor = glm::vec3(1.0f, 1.0f, 1.0f); // Pure white
	whiteMaterial.specularColor = glm::vec3(0.1f, 0.1f, 0.1f);
	whiteMaterial.shininess = 8.0f;
	whiteMaterial.tag = "white";
	m_objectMaterials.push_back(whiteMaterial);
}

/***********************************************************
 *  SetupSceneLights()
 *
 *  This method is called to add and configure the light
 *  sources for the 3D scene.  There are up to 4 light sources.
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
	// this line of code is NEEDED for telling the shaders to render 
	// the 3D scene with custom lighting, if no light sources have
	// been added then the display window will be black - to use the 
	// default OpenGL lighting then comment out the following line
	m_pShaderManager->setBoolValue(g_UseLightingName, true);

	/*** STUDENTS - add the code BELOW for setting up light sources ***/
	/*** Up to four light sources can be defined. Refer to the code ***/
	/*** in the OpenGL Sample for help                              ***/

	// MAIN KEY LIGHT (cool daylight, pure white)
	m_pShaderManager->setVec3Value("lightSources[0].position", 0.0f, 12.0f, 0.0f);
	m_pShaderManager->setVec3Value("lightSources[0].ambientColor", 0.02f, 0.02f, 0.02f);
	m_pShaderManager->setVec3Value("lightSources[0].diffuseColor", 1.0f, 1.0f, 1.0f); // Pure white
	m_pShaderManager->setVec3Value("lightSources[0].specularColor", 1.0f, 1.0f, 1.0f); // Pure white specular
	m_pShaderManager->setFloatValue("lightSources[0].focalStrength", 200.0f);
	m_pShaderManager->setFloatValue("lightSources[0].specularIntensity", 0.01f);

	// FILL LIGHT (slightly cool, soft)
	m_pShaderManager->setVec3Value("lightSources[1].position", -6.0f, 8.0f, 6.0f);
	m_pShaderManager->setVec3Value("lightSources[1].ambientColor", 0.015f, 0.015f, 0.015f);
	m_pShaderManager->setVec3Value("lightSources[1].diffuseColor", 0.95f, 0.98f, 1.0f); // Slightly cool
	m_pShaderManager->setVec3Value("lightSources[1].specularColor", 0.8f, 0.8f, 0.8f);
	m_pShaderManager->setFloatValue("lightSources[1].focalStrength", 150.0f);
	m_pShaderManager->setFloatValue("lightSources[1].specularIntensity", 0.005f);

	// RIM LIGHT (cool, subtle)
	m_pShaderManager->setVec3Value("lightSources[2].position", 8.0f, 7.0f, -8.0f);
	m_pShaderManager->setVec3Value("lightSources[2].ambientColor", 0.01f, 0.01f, 0.01f);
	m_pShaderManager->setVec3Value("lightSources[2].diffuseColor", 0.9f, 0.95f, 1.0f); // Cool rim
	m_pShaderManager->setVec3Value("lightSources[2].specularColor", 0.6f, 0.6f, 0.6f);
	m_pShaderManager->setFloatValue("lightSources[2].focalStrength", 120.0f);
	m_pShaderManager->setFloatValue("lightSources[2].specularIntensity", 0.003f);

	// BOUNCE LIGHT (neutral, very soft)
	m_pShaderManager->setVec3Value("lightSources[3].position", 0.0f, 4.0f, 0.0f);
	m_pShaderManager->setVec3Value("lightSources[3].ambientColor", 0.012f, 0.012f, 0.012f);
	m_pShaderManager->setVec3Value("lightSources[3].diffuseColor", 0.85f, 0.85f, 0.85f); // Neutral bounce
	m_pShaderManager->setVec3Value("lightSources[3].specularColor", 0.0f, 0.0f, 0.0f);
	m_pShaderManager->setFloatValue("lightSources[3].focalStrength", 180.0f);
	m_pShaderManager->setFloatValue("lightSources[3].specularIntensity", 0.0f);

	m_pShaderManager->setBoolValue("bUseLighting", true);
}


/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{

	// Ensure row alignment matches arbitrary image widths (1 byte)
	glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	// load the textures for the 3D scene
	LoadSceneTextures();
	DefineObjectMaterials();
	SetupSceneLights();

	// only one instance of a particular mesh needs to be
	// loaded in memory no matter how many times it is drawn
	// in the rendered 3D scene
	using Loader = void(ShapeMeshes::*)();

	// Define the shapes to be loaded into memory
	static constexpr Loader loaders[] = {
	  &ShapeMeshes::LoadBoxMesh,
	  &ShapeMeshes::LoadCylinderMesh, // While we dont use a cylcinder yet, we will for future stages
	  &ShapeMeshes::LoadTaperedCylinderMesh,
	  &ShapeMeshes::LoadPlaneMesh,
	};

	// Loop over the list of shapes
	for (auto fn : loaders) {
		(m_basicMeshes->*fn)();
	}
	// taurus mesh can take an additional param thickness
	m_basicMeshes->LoadTorusMesh();
}

/***********************************************************
 *  CreatePictureFrameWithToruses()
 *
 *  This method is used for creating a picture frame with toruses.
 *	This take the object base position and scale factor to create the picture frame.
 *	The picture frame is created using the following shapes:
 *		- Plane
 *		- Box
 *		- Torus
 *		- Half Torus
 ***********************************************************/
void SceneManager::CreatePictureFrameWithToruses(
	const glm::vec3& basePosition,
	const glm::vec3& scaleFactor,
	const std::string& pictureTexture,
	const std::string& frameTexture,
	const std::string& torusTexture)
{
	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	// ================================================
	// Picture Frame - Picture Plane
	// ================================================

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.5f * scaleFactor.x, 0.02f * scaleFactor.y, 0.25f * scaleFactor.z);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 90.0f;
	ZrotationDegrees = 90.0f;

	// set the XYZ position for the mesh
	positionXYZ = basePosition;

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(0.15f, 0.15f, 0.15f, 1.0f);
	SetShaderTexture(pictureTexture);
	m_basicMeshes->DrawPlaneMesh();

	// ================================================
	// Picture Frame Structure
	// ================================================

	const float frameOffset = 0.1f * scaleFactor.x;

	// Extra z offset to prevent flickering on overlapping objects
	const glm::vec3 frameOffsets[8] = {
		glm::vec3(basePosition.x, basePosition.y - (frameOffset + 0.7f * scaleFactor.x), basePosition.z + 0.001), // bottom
		glm::vec3(basePosition.x, basePosition.y + (frameOffset + 0.7f * scaleFactor.x), basePosition.z + 0.001), // top
		glm::vec3(basePosition.x - (frameOffset + 0.5f * scaleFactor.x), basePosition.y, basePosition.z), // left
		glm::vec3(basePosition.x + (frameOffset + 0.5f * scaleFactor.x), basePosition.y, basePosition.z), // right
		glm::vec3(basePosition.x, basePosition.y - (frameOffset + 0.4f * scaleFactor.x), basePosition.z + 0.001), // inner bottom
		glm::vec3(basePosition.x, basePosition.y + (frameOffset + 0.4f * scaleFactor.x), basePosition.z + 0.001), // inner top
		glm::vec3(basePosition.x - (frameOffset + 0.15f * scaleFactor.x), basePosition.y, basePosition.z), // inner left
		glm::vec3(basePosition.x + (frameOffset + 0.15f * scaleFactor.x), basePosition.y, basePosition.z), // inner right
	};

	// Only 2 rotation patterns: vertical (0°) vs horizontal (90°)
	const glm::vec3 frameRotations[2] = {
		glm::vec3(0.0f, 0.0f, 0.0f),   // vertical pieces
		glm::vec3(0.0f, 0.0f, 90.0f)    // horizontal pieces
	};

	// Base scale patterns: outer vs inner, vertical vs horizontal (scaled relative to scaleFactor)
	const glm::vec3 frameScale[8] = {
		glm::vec3(1.22f * scaleFactor.x, 0.02f, 0.1f * scaleFactor.x), // bottom
		glm::vec3(1.22f * scaleFactor.x, 0.02f, 0.1f * scaleFactor.x), // top
		glm::vec3(1.6f * scaleFactor.x, 0.02f, 0.1f * scaleFactor.x),  // left
		glm::vec3(1.6f * scaleFactor.x, 0.02f, 0.1f * scaleFactor.x),  // right
		glm::vec3(0.6f * scaleFactor.x, 0.1f * scaleFactor.y, 0.1f * scaleFactor.x),   // inner bottom
		glm::vec3(0.6f * scaleFactor.x, 0.1f * scaleFactor.y, 0.1f * scaleFactor.x),   // inner top
		glm::vec3(1.05f * scaleFactor.x, 0.1f * scaleFactor.y, 0.1f * scaleFactor.x),  // inner left
		glm::vec3(1.05f * scaleFactor.x, 0.1f * scaleFactor.y, 0.1f * scaleFactor.x),  // inner right
	};

	for (size_t i = 0; i < 8; i++)
	{
		// set the XYZ scale for the mesh
		scaleXYZ = frameScale[i];

		// set the XYZ rotation for the mesh (vertical vs horizontal)
		const bool isVertical = (i % 4) < 2; // bottom/top or inner bottom/top
		const int rotationIndex = isVertical ? 0 : 1;
		XrotationDegrees = frameRotations[rotationIndex].x;
		YrotationDegrees = frameRotations[rotationIndex].y;
		ZrotationDegrees = frameRotations[rotationIndex].z;

		// set the XYZ position for the mesh
		positionXYZ = frameOffsets[i];

		SetTransformations(
			scaleXYZ,
			XrotationDegrees,
			YrotationDegrees,
			ZrotationDegrees,
			positionXYZ);

		SetShaderColor(0.15f, 0.15f, 0.15f, 1.0f);
		SetShaderTexture(frameTexture);
		m_basicMeshes->DrawBoxMesh();
	}

	// ================================================
	// Half Toruses
	// ================================================

	// Create half toruses at specific positions with different scales
	const glm::vec3 halfTaurusPositions[7] = {
		glm::vec3(basePosition.x - 0.0f * scaleFactor.x, basePosition.y - (frameOffset + 0.45f * scaleFactor.x), basePosition.z), // bottom
		glm::vec3(basePosition.x - 0.15f * scaleFactor.x, basePosition.y - (frameOffset - 0.9f * scaleFactor.x), basePosition.z), // top
		glm::vec3(basePosition.x + 0.6f * scaleFactor.x, basePosition.y - (frameOffset + 0.46f * scaleFactor.x), basePosition.z), // bottom right
		glm::vec3(basePosition.x + 0.3f * scaleFactor.x, basePosition.y - (frameOffset - 0.05f * scaleFactor.x), basePosition.z), // middle right
		glm::vec3(basePosition.x - 0.3f * scaleFactor.x, basePosition.y - (frameOffset - 0.35f * scaleFactor.x), basePosition.z), // middle left
		glm::vec3(basePosition.x - 0.6f * scaleFactor.x, basePosition.y - (frameOffset + 0.2f * scaleFactor.x), basePosition.z), // bottom left
		glm::vec3(basePosition.x + 0.47f * scaleFactor.x, basePosition.y - (frameOffset - 0.67f * scaleFactor.x), basePosition.z), // top right
	};

	// Half taurus rotations
	const glm::vec3 halfTaurusRotations[8] = {
		glm::vec3(0.0f, 0.0f, -180.0f),
		glm::vec3(0.0f, 0.0f, 180.0f),
		glm::vec3(0.0f, 0.0f, 90.0f),
		glm::vec3(0.0f, 0.0f, -90.0f),
		glm::vec3(0.0f, 0.0f, 90.0f),
		glm::vec3(0.0f, 0.0f, -90.0f),
		glm::vec3(0.0f, 0.0f, 120.0f),
	};

	for (size_t i = 0; i < 7; i++)
	{
		// set the XYZ scale for the mesh
		scaleXYZ = glm::vec3(0.23f * scaleFactor.x, 0.23f * scaleFactor.y, 0.19f * scaleFactor.z);

		// set the XYZ rotation for the mesh
		XrotationDegrees = halfTaurusRotations[i].x;
		YrotationDegrees = halfTaurusRotations[i].y;
		ZrotationDegrees = halfTaurusRotations[i].z;

		// set the XYZ position for the mesh
		positionXYZ = halfTaurusPositions[i];

		SetTransformations(
			scaleXYZ,
			XrotationDegrees,
			YrotationDegrees,
			ZrotationDegrees,
			positionXYZ);

		SetShaderColor(0.15f, 0.15f, 0.15f, 1.0f);
		SetShaderTexture(torusTexture);
		m_basicMeshes->DrawHalfTorusMesh();
	}
}

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by 
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{
	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(20.0f, 1.0f, 10.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, 0.828f, 0.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(0.8980, 0.2235, 0.2078, 1);
	// Set Texture
	SetShaderTexture("floor");
	SetShaderMaterial("matteFloor");
	// draw the mesh with transformation values
	m_basicMeshes->DrawPlaneMesh();
	/****************************************************************/

	// -----------------------------
	// Nightstand constants
	// -----------------------------
	const float frontSign = 1.0f;
	const glm::vec3 bodyScale(6.0f, 2.5f, 4.0f);
	const glm::vec3 bodyPos(0.0f, 3.8f, 0.0f);

	// =========================
	// Nightstand: BODY (Box)
	// =========================

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = bodyScale;

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = bodyPos;

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(0.7804f, 0.6745f, 0.5490f, 1.0f); // light wood

	SetShaderTexture("main-body");
	SetShaderMaterial("light wood");


	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();
	/****************************************************************/

	// ===================================
	// Nightstand: DRAWER FRONT (plane)
	// ===================================

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	const glm::vec3 drawerScale(5.4f, 1.8f, 0.20f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	const float bodyHalfZ = bodyScale.z * 0.5f;
	positionXYZ = glm::vec3(
		bodyPos.x,
		bodyPos.y,
		bodyPos.z + frontSign * (bodyHalfZ + 0.10f)
	);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		drawerScale,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(0.8706f, 0.8706f, 0.8706f, 1.0f); // light gray/eggshell

	SetShaderTexture("drawer");
	SetShaderMaterial("light wood");

	// draw the mesh with transformation values
	m_basicMeshes->DrawBoxMesh();
	/****************************************************************/

	// ===========================================
	// Nightstand: LEGS (4 tapered cylinders)
	// ===========================================

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	const glm::vec3 legScale(0.28f, 2.0f, 0.28f);

	// We want to keep the legs evenly spaced here, so we cacluate 
	// the correct placement from the body dimensions

	// body bottom y:
	const float bodyBottomY = bodyPos.y - (bodyScale.y * 1.5);

	// place leg center so its top touches body bottom:
	const float legCenterY = bodyBottomY - (legScale.y * 0.5f);

	// small insets so legs don’t poke through the outside faces
	const float insetX = 0.2799f;
	const float insetZ = 0.35f;
	const float bodyHalfX = bodyScale.x * 0.5f;
	const float bodyHalfZ_forLegs = bodyScale.z * 0.5f;

	const glm::vec3 legOffsets[4] = {
		glm::vec3(+bodyHalfX - insetX, legCenterY, +bodyHalfZ_forLegs - insetZ),
		glm::vec3(-bodyHalfX + insetX, legCenterY, +bodyHalfZ_forLegs - insetZ),
		glm::vec3(+bodyHalfX - insetX, legCenterY, -bodyHalfZ_forLegs + insetZ),
		glm::vec3(-bodyHalfX + insetX, legCenterY, -bodyHalfZ_forLegs + insetZ)
	};

	for (int i = 0; i < 4; ++i)
	{
		// set the XYZ scale for the mesh
		scaleXYZ = legScale;

		// set the XYZ rotation for the mesh
		XrotationDegrees = 0.0f;
		YrotationDegrees = 0.0f;
		ZrotationDegrees = 180.0f;

		// set the XYZ position for the mesh
		positionXYZ = bodyPos + legOffsets[i];

		// set the transformations into memory to be used on the drawn meshes
		SetTransformations(
			scaleXYZ,
			XrotationDegrees,
			YrotationDegrees,
			ZrotationDegrees,
			positionXYZ);

		//SetShaderColor(0.4275f, 0.2980f, 0.2549f, 1.0f); // warm wood
		
		SetShaderTexture("legs");
		SetShaderMaterial("wood");

		m_basicMeshes->DrawTaperedCylinderMesh();
	}
	/****************************************************************/

	// ================================================
	// Nightstand: Drawer Recess (vertical plane)
	// ================================================

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.                        ***/
	/******************************************************************/

	scaleXYZ = glm::vec3(2.75f, 1.0f, 0.98f); 
	XrotationDegrees = 90.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// place just inside the body’s front face
	positionXYZ = glm::vec3(
		bodyPos.x,
		bodyPos.y + 0.05,
		bodyPos.z + (bodyHalfZ + 0.001) // outset slightly to break outside the boxes edge
	);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(0.15f, 0.15f, 0.15f, 0.4f); // dark gray, reduced opacity to give it a "shadow" feel

	m_basicMeshes->DrawPlaneMesh();
	/****************************************************************/
	// -----------------------------
	// Lamp constants
	// -----------------------------
	const float frontLogs = -0.16f;
	const glm::vec3 lampScale(2.0f, 0.15f, 1.7f);
	const glm::vec3 lampPos(-1.7f, 5.125f, 0.0f);

	// ================================================
	// Lamp: Lamp Base
	// ================================================

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.                        ***/
	/******************************************************************/

	// set the XYZ scale for the mesh
	scaleXYZ = lampScale;

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = lampPos;

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(0.15f, 0.15f, 0.15f, 1.0f); // dark gray
	//SetShaderTexture("gold");

	m_basicMeshes->DrawBoxMesh();
	/****************************************************************/

	// ================================================
	// Lamp: Lamp pole
	// ================================================

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.                        ***/
	/******************************************************************/

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(0.05f, 2.8f, 0.05f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	const float lampHalfZ = lampScale.z * 0.5f;
	positionXYZ = glm::vec3(
		lampPos.x,
		lampPos.y,
		lampPos.z * 0.5f
	);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(0.15f, 0.15f, 0.15f, 1.0f); // dark gray

	m_basicMeshes->DrawCylinderMesh();
	/****************************************************************/

	// ================================================
	// Lamp: Lamp shade
	// ================================================

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.                        ***/
	/******************************************************************/

	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(2.0f, 1.3f, 1.5f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(
		lampPos.x,
		lampPos.y + 3.0f,
		lampPos.z * 0.5f
	);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderColor(1.0f, 1.0f, 1.0f, 0.98f); // Pure white
	SetShaderMaterial("white");

	m_basicMeshes->DrawBoxMesh();
	/****************************************************************/

	// ================================================
	// Nightstand: Logs
	// ================================================

	const float yLogOffset = 0.30f;
	const float baseY = lampPos.y + 0.22f;
	const glm::vec3 lampBasePos(lampPos.x + 0.9f, 0.0f, lampPos.z + (lampHalfZ + frontLogs));

	for (int i = 0; i < 4; ++i)   // exactly 4 logs
	{
		// set the XYZ scale for the mesh
		scaleXYZ = glm::vec3(0.15f, 1.8f, 0.15f);

		// set the XYZ rotation for the mesh (lay the cylinder sideways)
		XrotationDegrees = 0.0f;
		YrotationDegrees = 0.0f;
		ZrotationDegrees = 90.0f;

		// set the XYZ position for the mesh
		positionXYZ = glm::vec3(lampBasePos.x, baseY + yLogOffset * i, lampBasePos.z);

		SetTransformations(
			scaleXYZ,
			XrotationDegrees,
			YrotationDegrees,
			ZrotationDegrees,
			positionXYZ);

		SetShaderColor(0.15f, 0.15f, 0.15f, 1.0f);
		SetShaderTexture("bark");
		m_basicMeshes->DrawCylinderMesh();
	}
	/****************************************************************/

	// ================================================
	// Nightstand: Books
	// ================================================

	const float yBookOffset = 0.199f;
	const float xBookOffset = 0.1f; // Offset the x axis to keep books aligned to the left when resizing
	const float xBookSizeDecrease = 0.2f;
	const glm::vec3 bookBasePos(1.5f, lampPos.y + 0.03, 1.0f);
	const std::string bookTextures[2] = {"blue_book", "red_book"};
	const std::string paperTexture = "paper";


	for (int i = 0; i < 2; ++i)
	{
		// Main book body
		scaleXYZ = glm::vec3(2.1f - (xBookSizeDecrease * i), 0.2f, 1.0f);
		XrotationDegrees = 0.0f;
		YrotationDegrees = 0.0f;
		ZrotationDegrees = 0.0f;
		positionXYZ = glm::vec3(bookBasePos.x - (xBookOffset * i), bookBasePos.y + (yBookOffset * i), bookBasePos.z);

		SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);
		SetShaderColor(0.15f, 0.15f, 0.15f, 1.0f);
		SetShaderTexture(bookTextures[i]);
		m_basicMeshes->DrawBoxMesh();

		// Add 3 thin paper slices around the edges with small inset
		const float bookWidth = 2.1f - (xBookSizeDecrease * i);
		const float bookX = bookBasePos.x - (xBookOffset * i);
		const float bookY = bookBasePos.y + (yBookOffset * i);
		const float bookZ = bookBasePos.z;
		const float inset = 0.006f; // Small inset to recess into the book

		// Back edge slice
		scaleXYZ = glm::vec3(bookWidth - 0.02f, 0.2f - 0.02f, 0.015f);
		positionXYZ = glm::vec3(bookX, bookY, bookZ - 0.5f + inset);
		SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
		SetShaderColor(0.15f, 0.15f, 0.15f, 1.0f);
		SetShaderTexture(paperTexture);
		m_basicMeshes->DrawBoxMesh();

		// Left edge slice - moved toward back by 0.001
		scaleXYZ = glm::vec3(0.015f, 0.2f - 0.02f, 0.98f);
		positionXYZ = glm::vec3(bookX - (bookWidth/2 - inset), bookY, bookZ - 0.011f);
		SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
		SetShaderColor(0.15f, 0.15f, 0.15f, 1.0f);
		SetShaderTexture(paperTexture);
		m_basicMeshes->DrawBoxMesh();

		// Right edge slice - moved toward back by 0.001
		scaleXYZ = glm::vec3(0.015f, 0.2f - 0.02f, 0.98f);
		positionXYZ = glm::vec3(bookX + (bookWidth/2 - inset), bookY, bookZ - 0.011f);
		SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
		SetShaderColor(0.15f, 0.15f, 0.15f, 1.0f);
		SetShaderTexture(paperTexture);
		m_basicMeshes->DrawBoxMesh();
	}
	/****************************************************************/

	// ================================================
	// Nightstand: Picture Frame 1
	// ================================================

	const glm::vec3 picFrameOneBasePos(1.9f, lampPos.y + 0.73f, -1.0f);
	const glm::vec3 frameOneBaseScaleFactor(1.0f, 1.0f, 1.0f);

	// Create picture frame with toruses using helper function
	CreatePictureFrameWithToruses(picFrameOneBasePos, frameOneBaseScaleFactor, "drawer", "glass", "glass");
	/****************************************************************/

	// ================================================
	// Nightstand: Picture Frame 2
	// ================================================

	const glm::vec3 picFrameTwoBasePos(0.5f, lampPos.y + 0.53f, -1.0f);
	const glm::vec3 frameTwoBaseScaleFactor(0.75f, 0.75f, 0.75f);

	// Create picture frame with toruses using helper function
	CreatePictureFrameWithToruses(picFrameTwoBasePos, frameTwoBaseScaleFactor, "drawer", "glass", "glass");
	/****************************************************************/
}
